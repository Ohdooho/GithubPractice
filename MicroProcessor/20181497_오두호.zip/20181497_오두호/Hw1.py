print("20181497 오두호")

code = []
ham = [0,0,0,0,0,0,0,0,0,0,0,0]
a = input()
t = 0
for i in range(len(a)):
    code.append(int(a[i]))
print("입력된 데이터:",a)
for j in range(11):
    if j == 0 or j == 1 or j == 3 or j == 7:
        continue
    else:
        ham[j]=code[t]
        t+=1
ham[0]=ham[2]^ham[4]^ham[6]^ham[8]^ham[10]
ham[1]=ham[2]^ham[5]^ham[6]^ham[9]^ham[10]
ham[3]=ham[4]^ham[5]^ham[6]^ham[11]
ham[7]=ham[8]^ham[9]^ham[10]^ham[11]
print("해밍코드: ",end="")
for i in range(len(ham)):
    print(ham[i],end="")
