print("20181497 오두호")
code = []
crc = [0,0,0]
tmp = 0
fcs = 0
print("비트열을 입력하시오.")
a = input()
for i in range(len(a)):
    code.append(int(a[i]))
print("입력된 비트열:",a)

for i in range(len(code)):
    tmp = code[i] ^ crc[0]
    crc[0] = tmp ^ crc[1]
    crc[1] = crc[2]
    crc[2] = tmp
    fcs = str(crc[0])+str(crc[1])+str(crc[2])
    print(fcs)
print("FCS:",fcs)




