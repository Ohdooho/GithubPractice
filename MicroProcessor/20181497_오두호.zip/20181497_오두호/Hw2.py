print("20181497 오두호")
parity = []
code = []
print("해밍코드를 입력하시오.")
a = input()
for i in range(len(a)):
    code.append(int(a[i]))
print("입력된 해밍코드:",a)

p1 =code[0]^code[2]^code[4]^code[6]^code[8]^code[10]
parity.append(p1)
p2 =code[1]^code[2]^code[5]^code[6]^code[9]^code[10]
parity.append(p2)
p4 =code[3]^code[4]^code[5]^code[6]^code[11]
parity.append(p4)
p8 =code[7]^code[8]^code[9]^code[10]^code[11]
parity.append(p8)

b = str(parity[3])+str(parity[2])+str(parity[1])+str(parity[0])
error = int(b,2)
if code[error-1]==1:
    code[error-1]=0
else:
    code[error-1]=1
if error == 0:
    print("에러 없음")
else:
    print(error,"번째 비트에 에러 발생. 수정된 코드:",end=" ")
    for i in range(len(code)):
        print(code[i],end="")
